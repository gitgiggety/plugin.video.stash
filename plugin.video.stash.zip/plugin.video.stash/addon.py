from resources.lib.plugin import run

if __name__ == '__main__':
    run()
